<?php


$host="74.207.243.183";
$port=3306;
$socket="";
$user="root";
$password="desa";
$dbname="pruebas";

$conn = mysqli_connect($host, $user, $password, $dbname, $port, $socket)
    or die ('Could not connect to the database server '. mysqli_connect_error());
    

?> 